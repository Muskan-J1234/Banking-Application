package com.moneytap.exception;

public class AccountNoNotFound extends Exception{
    public AccountNoNotFound(String message) {
        super(message);
    }
}
