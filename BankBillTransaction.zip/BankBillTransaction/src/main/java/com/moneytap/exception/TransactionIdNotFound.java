package com.moneytap.exception;

public class TransactionIdNotFound extends Exception{
    public TransactionIdNotFound(String message) {
        super(message);
    }
}
