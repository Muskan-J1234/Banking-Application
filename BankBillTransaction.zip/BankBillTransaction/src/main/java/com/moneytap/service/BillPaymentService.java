package com.moneytap.service;

import com.moneytap.exception.NotEnoughBalance;
import com.moneytap.model.BillPayment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Timestamp;

public interface BillPaymentService {
    void addBill(String billType, double amount, String walletId) throws NotEnoughBalance;
    BillPayment viewBill(String billId);
}
