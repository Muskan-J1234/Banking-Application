package com.moneytap.service;

import com.moneytap.exception.AccountNoNotFound;
import com.moneytap.model.BankAccount;
import com.moneytap.model.Customer;
import com.moneytap.repository.BankAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class BankAccountServiceImpl implements BankAccountService{

    private static String customerUrl = "http://customer-addbeneficiary-service/customer/";
    @Autowired
    BankAccountRepository bankAccountRepository;

    @Autowired
    RestTemplate restTemplate;

    @Override
    public void addBankAccount(String IFSCCode, String bankName, double balance, String customerId) {

            Customer customer = restTemplate.getForObject(customerUrl + customerId, Customer.class);
            BankAccount bankAccount = new BankAccount(IFSCCode, bankName, balance, customer);
            bankAccountRepository.save(bankAccount);

    }
    @Override
    public List<BankAccount> getAllBankAccounts() {
        return (List<BankAccount>) bankAccountRepository.findAll();
    }

    @Override
    public void removeAccount(Long accountNumber) {
        bankAccountRepository.deleteById(accountNumber);
    }

    @Override
    public void updateAccount(BankAccount bankAccount) {
        bankAccountRepository.save(bankAccount);
    }

    @Override
    public BankAccount getAccountById(Long accountNumber) throws AccountNoNotFound {

        BankAccount bankAccount = bankAccountRepository.findById(accountNumber).get();
        if(bankAccount==null) throw  new AccountNoNotFound("Account Number does not exist");

        return bankAccount;
    }
}
