package com.moneytap.service;

import com.moneytap.exception.AccountNoNotFound;
import com.moneytap.model.BankAccount;

import java.util.List;

public interface BankAccountService {
    void addBankAccount(String IFSCCode,String bankName,double balance,String customerId);
    List<BankAccount> getAllBankAccounts();
    void removeAccount(Long accountNumber);
    void updateAccount(BankAccount bankAccount);
    BankAccount getAccountById(Long accountNumber) throws AccountNoNotFound;

}
