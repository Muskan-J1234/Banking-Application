package com.moneytap.service;

import com.moneytap.exception.NotEnoughBalance;
import com.moneytap.model.BillPayment;
import com.moneytap.model.Wallet;
import com.moneytap.repository.BillPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.time.LocalDate;

@Service
public class BillPaymentServiceImpl implements BillPaymentService{
    private static String walletUrl = "http://main-service/wallet/";

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    BillPaymentRepository billPaymentRepository;

    @Override
    public void addBill(String billType, double amount, String walletId) throws NotEnoughBalance {
        Wallet userWallet = restTemplate.getForObject(walletUrl+"getWallet/"+walletId, Wallet.class);
        BillPayment billPayment = new BillPayment(billType, amount, userWallet);
        if(amount >= userWallet.getBalance()-100){
            throw new NotEnoughBalance("Not enough balance");
        }
        else{
            billPayment.setPaymentDate(LocalDate.now());
            billPaymentRepository.save(billPayment);
        }
    }

    @Override
    public BillPayment viewBill(String billId) {
        return billPaymentRepository.findById(billId).get();
    }
}
