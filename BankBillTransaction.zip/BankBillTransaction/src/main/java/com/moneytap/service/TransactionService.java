package com.moneytap.service;

import com.moneytap.model.Transaction;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

public interface TransactionService {
    public void addTransaction(Transaction transaction);
    public List<Transaction> viewAllTransactions();
    public List<Transaction> viewTransactionByType(String transactionType);
    public List<Transaction> viewTransactionByTransactionDate(LocalDate date);
}
