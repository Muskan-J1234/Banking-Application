package com.moneytap.repository;

import com.moneytap.model.Transaction;
import org.springframework.data.repository.CrudRepository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

public interface TransactionRepository extends CrudRepository<Transaction, Integer> {
    List<Transaction> findByTransactionType(String Type);
    List<Transaction> findByDate(LocalDate date);
}
