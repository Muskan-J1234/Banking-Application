package com.moneytap.controller;

import com.moneytap.exception.AccountNoNotFound;
import com.moneytap.model.BankAccount;
import com.moneytap.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bank_account")
public class BankAccountController {

    @Autowired
    BankAccountService bankAccountService;

    @GetMapping("/getALlbankAccounts")
    public List<BankAccount> getAllAccounts(){
        return bankAccountService.getAllBankAccounts();
    }

    @PostMapping("/{IFSCCode}/{bankName}/{balance}/{cId}")
    public void addBankAccount(@PathVariable String IFSCCode, @PathVariable String bankName, @PathVariable double balance, @PathVariable String cId)
    {
        bankAccountService.addBankAccount(IFSCCode, bankName, balance, cId);

    }
    @DeleteMapping("/{accNumber}")
    public void removeAccount(@PathVariable String accNumber){
        Long accountNumber = Long.valueOf(accNumber);
        bankAccountService.removeAccount(accountNumber);
    }

    @PostMapping("update")
    public void updateAccount(@RequestBody BankAccount bankAccount){
        bankAccountService.updateAccount(bankAccount);
    }

    @GetMapping("bankById/{accNumber}")
    public BankAccount getAccountById(@PathVariable String accNumber) throws AccountNoNotFound {
        Long accountNumber = Long.valueOf(accNumber);
        return bankAccountService.getAccountById(accountNumber);
    }


}
