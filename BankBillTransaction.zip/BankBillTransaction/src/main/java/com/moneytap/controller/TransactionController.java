package com.moneytap.controller;


import com.moneytap.model.Transaction;
import com.moneytap.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    TransactionService transactionService;

    @PostMapping("/add/{transaction}")
    public void addTransaction(@RequestBody Transaction transaction){
        transactionService.addTransaction(transaction);
    }

    @GetMapping("/viewAll")
    public List<Transaction> viewAllTransactions(){
        return transactionService.viewAllTransactions();
    }

    @GetMapping("/GetTransactionByType/{type}")
    public List<Transaction> viewTransactionsByType(@PathVariable String type){
        return transactionService.viewTransactionByType(type);
    }

    @GetMapping("/GetTransactionByDate/{strDate}")
    public List<Transaction> viewTransactionsByDate(@PathVariable String strDate){
        LocalDate date = LocalDate.parse(strDate);
        return transactionService.viewTransactionByTransactionDate(date);
    }
}
