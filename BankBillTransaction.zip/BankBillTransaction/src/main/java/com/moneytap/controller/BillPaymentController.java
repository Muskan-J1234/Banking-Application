package com.moneytap.controller;

import com.moneytap.exception.NotEnoughBalance;
import com.moneytap.model.BillPayment;
import com.moneytap.service.BillPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;

@RestController
@RequestMapping("/bill_payment")
public class BillPaymentController {

    @Autowired
    BillPaymentService billPaymentService;

    @PostMapping("/addBill/{billType}/{amount}/{walletId}")
    public void addBillPayment(@PathVariable String billType, @PathVariable double amount, @PathVariable String walletId) throws NotEnoughBalance {
        billPaymentService.addBill(billType, amount, walletId);
    }

    @GetMapping("/{billId}")
    public BillPayment viewBill(@PathVariable String billId){
        return billPaymentService.viewBill(billId);
    }
}
