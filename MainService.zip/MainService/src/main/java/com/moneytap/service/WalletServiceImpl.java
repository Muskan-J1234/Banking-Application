package com.moneytap.service;

import com.moneytap.exceptions.NotEnoughBalance;
import com.moneytap.model.*;
import com.moneytap.repository.CustomerRepository;
import com.moneytap.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class WalletServiceImpl implements WalletService{

    static String bankUrl = "http://bank-bill-transaction-service/bank_account/";
    static String beneficiaryUrl = "http://customer-addbeneficiary-service/beneficiary/details/";
    static String transactionUrl = "http://bank-bill-transaction-service/transaction/add/";

    @Autowired
    WalletRepository walletRepository;

    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    RestTemplate restTemplate;

    @Override
    public void addWallet(double balance, String customerId, String accountNumber) {
        Customer customer = customerRepository.findById((long) Integer.parseInt(customerId)).get();
        BankAccount bankAccount = restTemplate.getForObject(bankUrl+"bankById/"+accountNumber, BankAccount.class);
        Wallet wallet = new Wallet(balance, customer, bankAccount);
        walletRepository.save(wallet);
    }

    @Override
    public Double getBalance(Long walletId) {
        return walletRepository.findById(walletId).get().getBalance();
    }

    @Override
    public void addMoneyToWallet(Long walletId, Double amount) throws NotEnoughBalance {
        Wallet currentUserWallet = walletRepository.findById(walletId).get();
        BankAccount currentBankAccount = currentUserWallet.getBankAccount();
        if(currentBankAccount.getBalance()<amount){
            throw new NotEnoughBalance("Not enough balance Please try again");
        }
        currentBankAccount.setBalance(currentBankAccount.getBalance()-amount);
        currentUserWallet.setBalance(currentUserWallet.getBalance()+amount);
        walletRepository.save(currentUserWallet);
        restTemplate.postForObject(bankUrl+"update", currentBankAccount, BankAccount.class);
    }

    @Override
    public void depositMoneyToBank(Long walletId, Double amount) throws NotEnoughBalance {
        Wallet currentUserWallet = walletRepository.findById(walletId).get();
        BankAccount currentBankAccount = currentUserWallet.getBankAccount();
        if(currentUserWallet.getBalance()<amount){
            throw new NotEnoughBalance("Not enough balance Please try again");
        }
        currentBankAccount.setBalance(currentBankAccount.getBalance()+amount);
        currentUserWallet.setBalance(currentUserWallet.getBalance()-amount);
        walletRepository.save(currentUserWallet);
        restTemplate.postForObject(bankUrl+"update", currentBankAccount, BankAccount.class);
    }

    @Override
    public void fundTransfer(Long userWalletId, Long beneficiaryId, Double amount) throws NotEnoughBalance {
        Beneficiary beneficiaryDetails = restTemplate.getForObject(beneficiaryUrl+beneficiaryId, Beneficiary.class);
        Wallet beneficiaryWallet = beneficiaryDetails.getBeneficiaryWallet();
        Wallet userWallet = walletRepository.findById(userWalletId).get();
        if(userWallet.getBalance() < amount){
            throw new NotEnoughBalance("Not enough balance Please try again");
        }
        userWallet.setBalance(userWallet.getBalance()-amount);
        beneficiaryWallet.setBalance(beneficiaryWallet.getBalance()+amount);
        LocalDate date = LocalDate.now();
        Transaction creditTransaction = new Transaction("Credit", amount, "Amount Recieved", beneficiaryWallet);
        creditTransaction.setDate(date);
        restTemplate.postForObject(transactionUrl+creditTransaction, creditTransaction, Transaction.class);
        Transaction debitTransaction = new Transaction("Debit", amount, "Amount transfered", userWallet);
        debitTransaction.setDate(date);
        // System.out.println(LocalDate.now());
        restTemplate.postForObject(transactionUrl+debitTransaction, debitTransaction, Transaction.class);
        walletRepository.save(userWallet);
        walletRepository.save(beneficiaryWallet);
    }

    @Override
    public Wallet getWalletById(Long walletId) {
        try {
            return walletRepository.findById(walletId).get();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Customer> getALlCustomer() {
        List<Customer> customerList = new ArrayList<>();
        customerRepository.findAll().forEach(customer -> customerList.add(customer));
        return customerList;

    }
}
