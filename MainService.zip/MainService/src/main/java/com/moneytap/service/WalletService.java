package com.moneytap.service;

import com.moneytap.exceptions.NotEnoughBalance;
import com.moneytap.model.Customer;
import com.moneytap.model.Wallet;

import java.util.List;

public interface WalletService {
    void addWallet(double balance, String customerId, String accountNumber);
    Double getBalance(Long walletId);
    Wallet getWalletById(Long walletId);
    void addMoneyToWallet(Long walletId, Double amount) throws NotEnoughBalance;
    void depositMoneyToBank(Long walletId, Double amount) throws NotEnoughBalance;
    void fundTransfer(Long userWalletId, Long beneficiaryId, Double amount) throws NotEnoughBalance;
    List<Customer> getALlCustomer();
}
