package com.moneytap.exceptions;

public class NotAdmin extends Exception{
    public NotAdmin(String message) {
        super(message);
    }
}
