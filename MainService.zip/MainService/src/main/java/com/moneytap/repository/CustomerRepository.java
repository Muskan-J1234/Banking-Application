package com.moneytap.repository;

import com.moneytap.model.Customer;
import jdk.nashorn.internal.objects.AccessorPropertyDescriptor;
import org.springframework.data.repository.CrudRepository;

public interface CustomerRepository extends CrudRepository<Customer, Long> {
    Customer findByName(String userName);
}
