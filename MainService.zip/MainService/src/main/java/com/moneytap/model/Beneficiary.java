package com.moneytap.model;

import javax.persistence.*;

@Entity
public class Beneficiary {

    @Id
    @SequenceGenerator(name = "seq10", initialValue = 800000)
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "seq10")
    private long beneficiaryId;

    @ManyToOne
    @JoinColumn(name="customerId")
    private Customer customer;

    @ManyToOne
    @JoinColumn(name="beneficiaryWalletId")
    private Wallet beneficiaryWallet;

    private String Name;
    private long mobileNumber;

    @ManyToOne
    @JoinColumn(name="customerWalletId")
    private Wallet userWallet;

    public Beneficiary() {
    }

    public Beneficiary(Customer customer, Wallet beneficiaryWallet, String name, int mobileNumber, Wallet userWallet) {
        this.customer = customer;
        this.beneficiaryWallet = beneficiaryWallet;
        this.Name = name;
        this.mobileNumber = mobileNumber;
        this.userWallet = userWallet;
    }

    public long getId() {
        return beneficiaryId;
    }

    public void setId(long id) {
        this.beneficiaryId = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Wallet getBeneficiaryWallet() {
        return beneficiaryWallet;
    }

    public void setBeneficiaryWallet(Wallet beneficiaryWallet) {
        this.beneficiaryWallet = beneficiaryWallet;
    }

    public Wallet getUserWallet() {
        return userWallet;
    }

    public void setUserWallet(Wallet userWallet) {
        this.userWallet = userWallet;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public long getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(long mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

}
