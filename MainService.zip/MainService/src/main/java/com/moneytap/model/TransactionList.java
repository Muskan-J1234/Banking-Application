package com.moneytap.model;

import java.util.List;

public class TransactionList {

    private List<Transaction> transactionList;

    public TransactionList() {
    }

    public List<Transaction> getTransactionList() {
        return transactionList;
    }

    public void setTransactionList(List<Transaction> transactionList) {
        this.transactionList = transactionList;
    }
}
