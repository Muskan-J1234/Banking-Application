package com.moneytap.controller;

import com.moneytap.exceptions.NotAdmin;
import com.moneytap.exceptions.NotEnoughBalance;
import com.moneytap.model.*;
import com.moneytap.repository.WalletRepository;
import com.moneytap.service.UserService;
import com.moneytap.service.WalletService;
import com.moneytap.utility.JWTUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/wallet")
public class WalletController {
    static String bankUrl = "http://bank-bill-transaction-service/bank_account/";
    static String beneficiaryUrl = "http://customer-addbeneficiary-service/beneficiary/";
    static String transactionUrl = "http://bank-bill-transaction-service/transaction/";
    static String customerUrl = "http://customer-addbeneficiary-service/customer/";
    static String billUrl = "http://bank-bill-transaction-service/bill_payment/";

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    WalletService walletService;

    @GetMapping("/GetALLCustomer")
    public List<Customer> getALLcustomer(@RequestHeader(name="Authorization") String token) throws NotAdmin {
        return walletService.getALlCustomer();
    }


    @PostMapping("/AddWalletToCustomer/{balance}/{customerId}/{accountNumber}")
    public void addWallet(@RequestHeader(name="Authorization") String token,@PathVariable double balance, @PathVariable String customerId, @PathVariable String accountNumber)
    {
        walletService.addWallet(balance, customerId, accountNumber);
    }

    @GetMapping("/GetWallet/{id}")
    public Wallet getWalletById(@RequestHeader(name="Authorization") String token,@PathVariable String id){
        Long walletId = Long.valueOf(id);
        return walletService.getWalletById(walletId);
    }

    @GetMapping("/GetWalletBalance/{id}")
    public double getBalance(@RequestHeader(name="Authorization") String token,@PathVariable String id){
        Long walletId = Long.valueOf(id);
        return walletService.getBalance(walletId);
    }

    @PostMapping("/AddMoneyToWallet/{strWalletId}/{strAmount}")
    public void addMoney(@RequestHeader(name="Authorization") String token,@PathVariable String strWalletId, @PathVariable String strAmount) throws NotEnoughBalance {
        Long walletId = Long.valueOf(strWalletId);
        Double amount = Double.valueOf(strAmount);
        walletService.addMoneyToWallet(walletId,amount);
    }

    @PostMapping("/DepositMoneyToBank/{strWalletId}/{strAmount}")
    public void depositMoney(@RequestHeader(name="Authorization") String token,@PathVariable String strWalletId, @PathVariable String strAmount) throws NotEnoughBalance {
        Long walletId = Long.valueOf(strWalletId);
        Double amount = Double.valueOf(strAmount);
        walletService.depositMoneyToBank(walletId,amount);
    }

    @PostMapping("/FundTransfer/{userWallet}/{strBeneficiaryId}/{amount}")
    public void fundTransfer(@RequestHeader(name="Authorization") String token,@PathVariable String userWallet, @PathVariable String strBeneficiaryId, @PathVariable Double amount)throws NotEnoughBalance{
        Long userWalletId = Long.valueOf(userWallet);
        Long beneficiaryId = Long.valueOf(strBeneficiaryId);
        walletService.fundTransfer(userWalletId, beneficiaryId, amount);
    }

    @PostMapping("/AddBankAccountToCustomer/{IFSCCode}/{bankName}/{balance}/{cId}")
    public void addBankAccount(@RequestHeader(name="Authorization") String token,@PathVariable String IFSCCode, @PathVariable String bankName, @PathVariable double balance, @PathVariable String cId)
    {
        Customer customer = restTemplate.getForObject(customerUrl + cId, Customer.class);
        BankAccount bankAccount = new BankAccount(IFSCCode,bankName,balance,customer);
        restTemplate.postForObject(bankUrl+IFSCCode+"/"+bankName+"/"+balance+"/"+cId,bankAccount, BankAccount.class);

    }

    @PostMapping("/addCustomer/{name}/{num}/{password}")
    public void addCustomer(@RequestHeader(name="Authorization") String token,@PathVariable String name, @PathVariable String num , @PathVariable String password)
    {
        Long l = Long.valueOf(num);
        Customer customer1 = new Customer(name,l,password);
        restTemplate.postForObject(customerUrl+"addCustomer/"+name+"/"+num+"/"+password,customer1,Customer.class);
    }


    @GetMapping("/customer/{id}")
    Customer getCustomerById(@RequestHeader(name="Authorization") String token,@PathVariable String id) {
       // Long customerId = Long.valueOf(id);
        Customer customer = restTemplate.getForObject(customerUrl+id,Customer.class);
        return customer;
    }

    @PostMapping("/addBeneficiary/{wId}/{bWId}")
    public void addBeneficiaryDetails(@RequestHeader(name="Authorization") String token,@PathVariable String wId,@PathVariable String bWId){
        Beneficiary beneficiary = new Beneficiary();
        restTemplate.postForObject(beneficiaryUrl+"add/"+wId+"/"+bWId, beneficiary, Beneficiary.class);
    }

    @GetMapping("/BeneficairyDetails/{id}")
    public Beneficiary viewBeneficiaryDetails(@RequestHeader(name="Authorization") String token,@PathVariable String id){
        Beneficiary beneficiary = new Beneficiary();
        beneficiary = restTemplate.getForObject(beneficiaryUrl+"details/"+id,Beneficiary.class);
        return beneficiary;
    }

    @GetMapping("/viewAllTransaction")
    public List<Transaction> viewAllTransactions(@RequestHeader(name="Authorization") String token){
        TransactionList transactionList1 = restTemplate.getForObject(transactionUrl+"viewAll",TransactionList.class);
        System.out.println(transactionList1);
        List<Transaction> transactionList= transactionList1.getTransactionList();
        return transactionList;
    }

    @GetMapping("/GetTransactionByType/{type}")
    public List<Transaction> viewTransactionsByType(@RequestHeader(name="Authorization") String token,@PathVariable String type){
        TransactionList transactionList1 = restTemplate.getForObject(transactionUrl+"GetTransactionByType/"+type,TransactionList.class);
        System.out.println(transactionList1);
        List<Transaction> transactionList= transactionList1.getTransactionList();
        return transactionList;
    }
    @PostMapping("/addBill/{billType}/{amount}/{walletId}")
    public void addBillPayment(@RequestHeader(name="Authorization") String token,@PathVariable String billType, @PathVariable double amount, @PathVariable String walletId){
        BillPayment billPayment = new BillPayment();
        restTemplate.postForObject(bankUrl+"addBill/"+billType+"/"+amount+"/"+walletId,billPayment,BillPayment.class);
    }

    @GetMapping("/viewBill/{billId}")
    public BillPayment viewBill(@RequestHeader(name="Authorization") String token,@RequestBody String billId){
        BillPayment billPayment = restTemplate.getForObject(billUrl+billId,BillPayment.class);
        return billPayment;
    }
}
