package com.moneytap.exception;

public class BeneficieryNotFound extends Exception{
    public BeneficieryNotFound(String message){
        super(message);
    }
}
