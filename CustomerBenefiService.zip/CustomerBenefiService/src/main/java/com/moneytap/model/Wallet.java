package com.moneytap.model;

import javax.persistence.*;

@Entity
public class Wallet {
    @Id
    @SequenceGenerator(name = "generator", initialValue = 20000)
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "generator")
    private long walletId;
    private double balance;

    @OneToOne
    @JoinColumn(name="customerId")
    private Customer customer;

    @OneToOne
    @JoinColumn(name="accountNumber")
    private BankAccount bankAccount;


    public Wallet() {
    }

    public Wallet(double balance, Customer customer, BankAccount bankAccount) {
        this.balance = balance;
        this.customer = customer;
        this.bankAccount = bankAccount;
    }

    public long getWalletId() {
        return walletId;
    }

    public void setWalletId(long walletId) {
        this.walletId = walletId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public BankAccount getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(BankAccount bankAccount) {
        this.bankAccount = bankAccount;
    }



}
