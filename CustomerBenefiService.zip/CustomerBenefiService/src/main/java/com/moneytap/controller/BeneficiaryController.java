package com.moneytap.controller;

import com.moneytap.exception.BeneficieryNotFound;
import com.moneytap.model.Beneficiary;
import com.moneytap.service.BeneficiaryDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/beneficiary")
public class BeneficiaryController {

    @Autowired
    BeneficiaryDetailsService beneficiaryDetailsService;

    @PostMapping("/add/{wId}/{bWId}")
    public void addBeneficiaryDetails(@PathVariable String wId,@PathVariable String bWId){
        beneficiaryDetailsService.addBeneficiary(wId, bWId);
    }

    @GetMapping("/details/{id}")
    public Beneficiary viewBeneficiaryDetails(@PathVariable String id) throws BeneficieryNotFound {
        Long beneficiaryId = Long.valueOf(id);
        return beneficiaryDetailsService.viewBeneficiaryDetails(beneficiaryId);
    }

    @DeleteMapping("/remove/{id}")
    public void removeBeneficiary(@PathVariable String id) throws BeneficieryNotFound {
        Long beneficiaryId = Long.valueOf(id);
        beneficiaryDetailsService.removeBeneficiary(beneficiaryId);
    }
}
