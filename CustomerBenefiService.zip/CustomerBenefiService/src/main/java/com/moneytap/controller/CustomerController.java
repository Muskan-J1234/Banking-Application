package com.moneytap.controller;

import com.moneytap.exception.CustomerNotFound;
import com.moneytap.model.Customer;
import com.moneytap.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @PostMapping("/addCustomer/{name}/{num}/{password}")
    public void addCustomer(@PathVariable String name, @PathVariable String num , @PathVariable String password)
    {
        Long l=Long.parseLong(num);
        Customer customer1 = new Customer(name,l,password);
        customerService.addCustomer(customer1);
    }

    @GetMapping("/{id}")
    Customer getCustomerById(@PathVariable String id) throws CustomerNotFound {
        Long l=Long.parseLong(id);
        return customerService.getCustomerById(l);
    }

    @DeleteMapping("/{id}")
    void delete(@PathVariable String id) throws CustomerNotFound {
        Long l=Long.parseLong(id);
        customerService.delete(l);
    }



}
