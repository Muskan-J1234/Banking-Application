package com.moneytap.service;

import com.moneytap.exception.BeneficieryNotFound;
import com.moneytap.model.Beneficiary;
import com.moneytap.model.Customer;
import com.moneytap.model.Wallet;
import com.moneytap.repository.BeneficiaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class BeneficiaryDetailsServiceImpl implements BeneficiaryDetailsService{
    private static String walletUrl = "http://main-service/wallet/";

    @Autowired
    RestTemplate restTemplate;
    @Autowired
    BeneficiaryRepository beneficiaryDetailsRepository;

    @Override
    public void addBeneficiary(String userWalletId, String beneficiaryWalletId) {
        Wallet userWallet = restTemplate.getForObject(walletUrl+"getWallet/"+userWalletId, Wallet.class);
        Wallet beneficiaryWallet = restTemplate.getForObject(walletUrl+"getWallet/"+beneficiaryWalletId, Wallet.class);
        Customer user = userWallet.getCustomer();
        long beneficiaryNumber = beneficiaryWallet.getCustomer().getMobileNumber();
        String beneficiaryName = beneficiaryWallet.getCustomer().getName();
        Beneficiary beneficiaryDetails = new Beneficiary(user, beneficiaryWallet, beneficiaryName, beneficiaryNumber, userWallet);
        beneficiaryDetailsRepository.save(beneficiaryDetails);
    }

    @Override
    public Beneficiary viewBeneficiaryDetails(Long beneficiaryId) throws BeneficieryNotFound {
        Beneficiary beneficiary = beneficiaryDetailsRepository.findById(beneficiaryId).get();
        if(beneficiary==null){
            throw  new BeneficieryNotFound("Beneficiary Does not exist");
        }
        return beneficiary;
    }

    @Override
    public void removeBeneficiary(Long beneficiaryId) throws BeneficieryNotFound {
        Beneficiary beneficiary = beneficiaryDetailsRepository.findById(beneficiaryId).get();
        if(beneficiary==null){
            throw  new BeneficieryNotFound("Beneficiary Does not exist");
        }
        beneficiaryDetailsRepository.deleteById(beneficiaryId);
    }
}
