package com.moneytap.service;

import com.moneytap.exception.CustomerNotFound;
import com.moneytap.model.Customer;

public interface CustomerService {
    void addCustomer(Customer customer);
    Customer getCustomerById(Long customerId) throws CustomerNotFound;
    void delete(Long customerId) throws CustomerNotFound;
}
