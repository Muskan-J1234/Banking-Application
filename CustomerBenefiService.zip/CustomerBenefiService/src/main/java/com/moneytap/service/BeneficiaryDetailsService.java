package com.moneytap.service;

import com.moneytap.exception.BeneficieryNotFound;
import com.moneytap.model.Beneficiary;

public interface BeneficiaryDetailsService {
    void addBeneficiary(String userWalletId, String beneficiaryWalletId);
    Beneficiary viewBeneficiaryDetails(Long beneficiaryId) throws BeneficieryNotFound;
    void removeBeneficiary(Long beneficiaryId) throws BeneficieryNotFound;
}
