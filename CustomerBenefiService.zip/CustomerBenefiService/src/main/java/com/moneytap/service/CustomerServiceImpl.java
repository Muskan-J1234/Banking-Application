package com.moneytap.service;

import com.moneytap.exception.CustomerNotFound;
import com.moneytap.model.Customer;
import com.moneytap.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    CustomerRepository customerRepository;

    @Override
    public void addCustomer(Customer customer)  {
        customerRepository.save(customer);
    }

    @Override
    public Customer getCustomerById(Long customerId) throws CustomerNotFound {
        Customer customer = customerRepository.findById(customerId).get();
        if(customer==null){
           throw new CustomerNotFound("Customer does not exist");
        }
        return customer;
    }

    @Override
    public void delete(Long customerId) throws CustomerNotFound {
        Customer customer = customerRepository.findById(customerId).get();
        if(customer==null){
            throw new CustomerNotFound("Customer does not exist");
        }
        customerRepository.delete(customer);

    }

}
